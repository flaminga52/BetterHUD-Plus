package dev.betterhud.client.hud.widgets;

import dev.betterhud.client.config.BetterHudConfig;
import dev.betterhud.client.util.ColorUtils;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class SystemWidget extends HudWidget {
    public SystemWidget(BetterHudConfig.WidgetPos pos) {
        super(pos);
        this.width = 80;
        this.height = 12;
    }

    @Override
    public void render(class_332 context, float tickDelta) {
        if (!isVisible()) return;

        class_310 client = class_310.method_1551();
        int fps = client.method_47599();

        int color;
        if (BetterHudConfig.instance.colorMode == 0) {
            color = ColorUtils.getChromaColor(4000);
        } else if (BetterHudConfig.instance.colorMode == 2) {
            color = ColorUtils.getDynamicColor(fps, 30, 144);
        } else {
            color = 0xFFFFFFFF;
        }

        context.method_51448().method_22903();
        context.method_51448().method_46416(getX(), getY(), 0);
        context.method_51448().method_22905(pos.scale, pos.scale, 1.0f);

        String text = "FPS: " + fps;
        if (pos.shadow) {
            context.method_25303(client.field_1772, text, 0, 0, color);
        } else {
            context.method_51433(client.field_1772, text, 0, 0, color, false);
        }

        context.method_51448().method_22909();
    }
}
