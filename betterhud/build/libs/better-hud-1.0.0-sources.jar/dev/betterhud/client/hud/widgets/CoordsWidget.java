package dev.betterhud.client.hud.widgets;

import dev.betterhud.client.config.BetterHudConfig;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class CoordsWidget extends HudWidget {
    public CoordsWidget(BetterHudConfig.WidgetPos pos) {
        super(pos);
        this.width = 120;
        this.height = 12;
    }

    @Override
    public void render(class_332 context, float tickDelta) {
        if (!isVisible()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        context.method_51448().method_22903();
        context.method_51448().method_46416(getX(), getY(), 0);
        context.method_51448().method_22905(pos.scale, pos.scale, 1.0f);

        int x = (int) client.field_1724.method_23317();
        int y = (int) client.field_1724.method_23318();
        int z = (int) client.field_1724.method_23321();

        String coords = String.format("XYZ: %d, %d, %d", x, y, z);
        int color = 0xFFFFFFFF;

        if (pos.shadow) {
            context.method_25303(client.field_1772, coords, 0, 0, color);
        } else {
            context.method_51433(client.field_1772, coords, 0, 0, color, false);
        }

        context.method_51448().method_22909();
    }
}
