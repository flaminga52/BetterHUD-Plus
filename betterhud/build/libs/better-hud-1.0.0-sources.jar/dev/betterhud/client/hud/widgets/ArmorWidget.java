package dev.betterhud.client.hud.widgets;

import dev.betterhud.client.config.BetterHudConfig;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_332;

public class ArmorWidget extends HudWidget {
    private static final int MARGIN = 2;
    private static final int ICON_SIZE = 16;
    private static final int TEXT_OFFSET_X = 20;
    private static final int LEGACY_DEFAULT_X = 10;
    private static final int LEGACY_DEFAULT_Y = 70;

    private static final class_1304[] ARMOR_ORDER = {
            class_1304.field_6169,
            class_1304.field_6174,
            class_1304.field_6172,
            class_1304.field_6166
    };

    private boolean defaultPositionApplied = false;

    public ArmorWidget(BetterHudConfig.WidgetPos pos) {
        super(pos);
    }

    public void snapToBottomRight(class_310 client) {
        if (client.method_22683() == null) {
            return;
        }
        updateLayout(client);
        if (width <= 0) {
            width = ICON_SIZE + 32;
            height = 64;
        }
        pos.x = client.method_22683().method_4486() - getWidth() - MARGIN;
        pos.y = client.method_22683().method_4502() - getHeight() - MARGIN;
    }

    private void ensureDefaultPosition(class_310 client) {
        if (defaultPositionApplied || client.method_22683() == null) {
            return;
        }
        if (pos.x == LEGACY_DEFAULT_X && pos.y == LEGACY_DEFAULT_Y) {
            snapToBottomRight(client);
        }
        defaultPositionApplied = true;
    }

    private void updateLayout(class_310 client) {
        if (client.field_1724 == null) {
            width = 0;
            height = 0;
            return;
        }

        boolean barsMode = BetterHudConfig.instance.armorMode == BetterHudConfig.ArmorMode.BARS;
        int rowHeight = barsMode ? 20 : 16;
        int itemCount = 0;
        int maxTextWidth = 0;

        for (class_1304 slot : ARMOR_ORDER) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (stack.method_7960()) {
                continue;
            }
            itemCount++;
            maxTextWidth = Math.max(maxTextWidth, client.field_1772.method_1727(getArmorInfo(stack)));
        }

        if (itemCount == 0) {
            width = 0;
            height = 0;
            return;
        }

        width = Math.max(ICON_SIZE, TEXT_OFFSET_X + maxTextWidth);
        height = itemCount * rowHeight;
    }

    @Override
    public boolean isHovered(double mouseX, double mouseY) {
        class_310 client = class_310.method_1551();
        ensureDefaultPosition(client);
        updateLayout(client);
        if (width <= 0 || height <= 0) {
            return false;
        }
        return super.isHovered(mouseX, mouseY);
    }

    @Override
    public void render(class_332 context, float tickDelta) {
        if (!isVisible()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        ensureDefaultPosition(client);
        updateLayout(client);
        if (width <= 0 || height <= 0) {
            return;
        }

        boolean barsMode = BetterHudConfig.instance.armorMode == BetterHudConfig.ArmorMode.BARS;
        int rowHeight = barsMode ? 20 : 16;

        context.method_51448().method_22903();
        context.method_51448().method_46416(getX(), getY(), 0);
        context.method_51448().method_22905(pos.scale, pos.scale, 1.0f);

        int yOffset = 0;
        for (class_1304 slot : ARMOR_ORDER) {
            class_1799 stack = client.field_1724.method_6118(slot);
            if (stack.method_7960()) {
                continue;
            }

            context.method_51445(stack, 0, yOffset);

            String info = getArmorInfo(stack);
            int color = getArmorTextColor(stack);

            if (pos.shadow) {
                context.method_25303(client.field_1772, info, TEXT_OFFSET_X, yOffset + 4, color);
            } else {
                context.method_51433(client.field_1772, info, TEXT_OFFSET_X, yOffset + 4, color, false);
            }

            if (barsMode) {
                renderDurabilityBar(context, stack, 0, yOffset + 14);
            }
            yOffset += rowHeight;
        }

        context.method_51448().method_22909();
    }

    private String getArmorInfo(class_1799 stack) {
        if (!stack.method_7963()) {
            return "100%";
        }

        int max = stack.method_7936();
        int current = max - stack.method_7919();
        int percent = max > 0 ? (current * 100) / max : 100;

        return switch (BetterHudConfig.instance.armorMode) {
            case PERCENTAGE -> percent + "%";
            case DURABILITY, DYNAMIC_COLOR -> current + "/" + max;
            case REMAINING -> String.valueOf(current);
            default -> percent + "%";
        };
    }

    private int getArmorTextColor(class_1799 stack) {
        BetterHudConfig.ArmorMode mode = BetterHudConfig.instance.armorMode;
        if (mode != BetterHudConfig.ArmorMode.DURABILITY
                && mode != BetterHudConfig.ArmorMode.DYNAMIC_COLOR
                && mode != BetterHudConfig.ArmorMode.PERCENTAGE) {
            return 0xFFFFFF;
        }
        if (!stack.method_7963()) {
            return 0x55FF55;
        }

        float percent = ((float) (stack.method_7936() - stack.method_7919()) / stack.method_7936()) * 100f;
        if (percent > 70) return 0x55FF55;
        if (percent > 40) return 0xFFFF55;
        if (percent > 15) return 0xFFAA00;
        return 0xFF5555;
    }

    private void renderDurabilityBar(class_332 context, class_1799 stack, int x, int y) {
        if (!stack.method_31578()) return;
        int barWidth = stack.method_31579();
        int barColor = stack.method_31580() | 0xFF000000;
        context.method_25294(x, y, x + barWidth, y + 1, barColor);
    }
}
