package dev.betterhud.client.hud.widgets;

import dev.betterhud.client.config.BetterHudConfig;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4074;

public class PotionWidget extends HudWidget {
    public PotionWidget(BetterHudConfig.WidgetPos pos) {
        super(pos);
        this.width = 60;
        this.height = 20;
    }

    @Override
    public void render(class_332 context, float tickDelta) {
        if (!isVisible()) return;

        class_310 client = class_310.method_1551();
        if (client.field_1724 == null || client.field_1687 == null) return;

        Collection<class_1293> effects = client.field_1724.method_6026();
        if (effects.isEmpty()) return;

        List<class_1293> sortedEffects = new ArrayList<>(effects);

        context.method_51448().method_22903();
        context.method_51448().method_46416(getX(), getY(), 0);
        context.method_51448().method_22905(pos.scale, pos.scale, 1.0f);

        class_4074 spriteManager = client.method_18505();
        int yOffset = 0;

        for (class_1293 effect : sortedEffects) {
            class_1291 type = effect.method_5579();

            context.method_25298(0, yOffset, 0, 18, 18, spriteManager.method_18663(type));

            String duration;
            if (effect.method_5584() >= 32767) {
                duration = "**:**";
            } else {
                int totalSeconds = Math.max(0, effect.method_5584() / 20);
                int minutes = totalSeconds / 60;
                int seconds = totalSeconds % 60;
                duration = String.format("%02d:%02d", minutes, seconds);
            }

            int textWidth = client.field_1772.method_1727(duration);
            context.method_25294(20, yOffset + 4, 22 + textWidth + 2, yOffset + 14, 0x80000000);

            int color = 0xFFFFFFFF;
            if (pos.shadow) {
                context.method_25303(client.field_1772, duration, 22, yOffset + 5, color);
            } else {
                context.method_51433(client.field_1772, duration, 22, yOffset + 5, color, false);
            }

            yOffset += 20;
        }

        this.height = Math.max(20, yOffset);
        context.method_51448().method_22909();
    }
}
