package dev.betterhud.client.hud.widgets;

import dev.betterhud.client.config.BetterHudConfig;
import net.minecraft.class_310;
import net.minecraft.class_332;

public abstract class HudWidget {
    protected final BetterHudConfig.WidgetPos pos;
    protected int width = 100;
    protected int height = 20;

    public HudWidget(BetterHudConfig.WidgetPos pos) {
        this.pos = pos;
    }

    public abstract void render(class_332 context, float tickDelta);

    public boolean isVisible() {
        return pos.visible;
    }

    public void setVisible(boolean visible) {
        pos.visible = visible;
    }

    public int getX() { return pos.x; }
    public int getY() { return pos.y; }
    public void setPos(int x, int y) {
        class_310 client = class_310.method_1551();
        int screenWidth = client.method_22683().method_4486();
        int screenHeight = client.method_22683().method_4502();

        int widgetWidth = getWidth();
        int widgetHeight = getHeight();

        pos.x = Math.max(0, Math.min(x, screenWidth - widgetWidth));
        pos.y = Math.max(0, Math.min(y, screenHeight - widgetHeight));
    }

    public int getWidth() { return (int)(width * pos.scale); }
    public int getHeight() { return (int)(height * pos.scale); }
    public float getScale() { return pos.scale; }

    public void setScale(float scale) {
        pos.scale = scale;
    }

    public boolean hasShadow() {
        return pos.shadow;
    }

    public void setShadow(boolean shadow) {
        pos.shadow = shadow;
    }

    public boolean isHovered(double mouseX, double mouseY) {
        return mouseX >= getX() && mouseX <= getX() + getWidth() &&
               mouseY >= getY() && mouseY <= getY() + getHeight();
    }
}
