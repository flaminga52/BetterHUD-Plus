package dev.betterhud.client.hud;

import dev.betterhud.client.config.BetterHudConfig;
import dev.betterhud.client.gui.HudConfigScreen;
import dev.betterhud.client.hud.widgets.*;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_332;
import java.util.ArrayList;
import java.util.List;

public class AnarchyHUD {
    public static final List<HudWidget> widgets = new ArrayList<>();

    public static void register() {
        BetterHudConfig.load();

        widgets.add(new SystemWidget(BetterHudConfig.instance.systemPos));

        widgets.add(new ArmorWidget(BetterHudConfig.instance.armorPos));

        widgets.add(new PotionWidget(BetterHudConfig.instance.potionPos));
        widgets.add(new CoordsWidget(BetterHudConfig.instance.coordsPos));

        HudRenderCallback.EVENT.register(AnarchyHUD::render);
    }

    private static void render(class_332 drawContext, float tickDelta) {
        class_310 client = class_310.method_1551();
        if (client.field_1690.field_1842 || client.field_1724 == null) return;
        if (client.field_1755 instanceof HudConfigScreen) return;

        for (HudWidget widget : widgets) {
            widget.render(drawContext, tickDelta);
        }
    }
}
