package dev.betterhud.client.gui;

import dev.betterhud.client.config.BetterHudConfig;
import dev.betterhud.client.hud.AnarchyHUD;
import dev.betterhud.client.hud.widgets.*;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class HudConfigScreen extends class_437 {
    private HudWidget draggingWidget = null;
    private double dragOffsetX, dragOffsetY;

    public HudConfigScreen() {
        super(class_2561.method_43470("Better HUD Settings"));
    }

    @Override
    protected void method_25426() {
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Save & Close"), button -> {
            BetterHudConfig.save();
            this.method_25419();
        }).method_46434(this.field_22789 / 2 - 50, this.field_22790 - 30, 100, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Armor Mode: " + BetterHudConfig.instance.armorMode.getName()), button -> {
            BetterHudConfig.instance.armorMode = BetterHudConfig.instance.armorMode.next();
            button.method_25355(class_2561.method_43470("Armor Mode: " + BetterHudConfig.instance.armorMode.getName()));
        }).method_46434(10, 10, 120, 20).method_46431());

        this.method_37063(class_4185.method_46430(class_2561.method_43470("RESET POSITIONS"), button -> {
            BetterHudConfig.instance.systemPos = new BetterHudConfig.WidgetPos(10, 10);
            BetterHudConfig.instance.armorPos = new BetterHudConfig.WidgetPos(0, 0);
            BetterHudConfig.instance.potionPos = new BetterHudConfig.WidgetPos(10, 130);
            BetterHudConfig.instance.coordsPos = new BetterHudConfig.WidgetPos(10, 190);

            AnarchyHUD.widgets.clear();
            AnarchyHUD.widgets.add(new SystemWidget(BetterHudConfig.instance.systemPos));

            ArmorWidget armorWidget = new ArmorWidget(BetterHudConfig.instance.armorPos);
            armorWidget.snapToBottomRight(class_310.method_1551());
            AnarchyHUD.widgets.add(armorWidget);

            AnarchyHUD.widgets.add(new PotionWidget(BetterHudConfig.instance.potionPos));
            AnarchyHUD.widgets.add(new CoordsWidget(BetterHudConfig.instance.coordsPos));

            BetterHudConfig.save();
        }).method_46434(this.field_22789 - 130, 10, 120, 20).method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context);

        context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 10, 0xFFFFFFFF);
        context.method_25300(this.field_22793, "L-Click: Drag | R-Click: Scale | M-Click: Shadow | Shift+L-Click: Toggle", this.field_22789 / 2, 25, 0xFFAAAAAA);

        for (HudWidget widget : AnarchyHUD.widgets) {
            if (!widget.isVisible() && !class_437.method_25441()) continue;

            if (!(widget instanceof ArmorWidget)) {
                int color = widget.isHovered(mouseX, mouseY) ? 0x88FFFFFF : 0x44FFFFFF;
                if (!widget.isVisible()) color = 0x44FF0000;

                context.method_25294(widget.getX() - 2, widget.getY() - 2,
                             widget.getX() + widget.getWidth() + 2,
                             widget.getY() + widget.getHeight() + 2, color);
            }

            widget.render(context, delta);
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25402(double mouseX, double mouseY, int button) {
        for (HudWidget widget : AnarchyHUD.widgets) {
            if (widget.isHovered(mouseX, mouseY)) {
                if (button == 0) {
                    if (class_437.method_25442()) {
                        widget.setVisible(!widget.isVisible());
                    } else {
                        draggingWidget = widget;
                        dragOffsetX = mouseX - widget.getX();
                        dragOffsetY = mouseY - widget.getY();
                    }
                    return true;
                } else if (button == 1) {
                    float scale = widget.getScale() + 0.25f;
                    if (scale > 2.0f) scale = 0.5f;
                    widget.setScale(scale);
                    return true;
                } else if (button == 2) {
                    widget.setShadow(!widget.hasShadow());
                    return true;
                }
            }
        }
        return super.method_25402(mouseX, mouseY, button);
    }

    @Override
    public boolean method_25406(double mouseX, double mouseY, int button) {
        draggingWidget = null;
        return super.method_25406(mouseX, mouseY, button);
    }

    @Override
    public void method_16014(double mouseX, double mouseY) {
        if (draggingWidget != null) {
            draggingWidget.setPos((int) (mouseX - dragOffsetX), (int) (mouseY - dragOffsetY));
        }
    }

    @Override
    public boolean method_25421() {
        return false;
    }
}
