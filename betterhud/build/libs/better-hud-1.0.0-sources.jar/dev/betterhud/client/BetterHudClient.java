package dev.betterhud.client;

import dev.betterhud.client.config.BetterHudConfig;
import dev.betterhud.client.gui.HudConfigScreen;
import dev.betterhud.client.hud.AnarchyHUD;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class BetterHudClient implements ClientModInitializer {
    private static class_304 settingsKey;

    @Override
    public void onInitializeClient() {
        BetterHudConfig.load();
        AnarchyHUD.register();

        settingsKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.betterhud.settings",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.betterhud.main"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (settingsKey.method_1436()) {
                if (client.field_1755 == null) {
                    client.method_1507(new HudConfigScreen());
                }
            }
        });
    }
}
